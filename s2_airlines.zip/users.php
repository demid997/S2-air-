<?php
$users = [
    "demid050677@gmail.com" => "Ss05062013",   // Логин: demid050677@gmail.com, Пароль: Ss05062013
    "Svetlana" => "Ss02062010",                 // Логин: Svetlana, Пароль: Ss02062010
    "Vladimir" => "Ss19081979",                 // Логин: Vladimir, Пароль: Ss19081979
    "Oksana" => "klassic"                       // Логин: Oksana, Пароль: klassic
];
?>