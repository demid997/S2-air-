<?php
session_start();
include 'users.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST['login'];
    $password = $_POST['password'];

    if (isset($users[$login]) && $users[$login] == $password) {
        $_SESSION['user'] = $login;
        header("Location: dashboard.php");
    } else {
        echo "Неверный логин или пароль.";
    }
}
?>