<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Вход | S2 Airlines</title>
</head>
<body>
  <h2>Вход в личный кабинет</h2>
  <form action="auth.php" method="POST">
    <input type="text" name="login" placeholder="Логин" required>
    <input type="password" name="password" placeholder="Пароль" required>
    <button type="submit">Войти</button>
  </form>
</body>
</html>