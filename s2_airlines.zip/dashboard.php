<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

function generateCard() {
    return "S2-" . rand(100000, 999999);
}
function generateBookingCode() {
    return strtoupper(substr(md5(time()), 0, 6));
}
?>

<h1>Добро пожаловать, <?= $_SESSION['user'] ?>!</h1>
<p>Ваша бонусная карта: <?= generateCard() ?></p>
<p>Ваш код бронирования: <?= generateBookingCode() ?></p>

<form action="routes.php" method="GET">
  <input type="text" name="from" placeholder="Откуда">
  <input type="text" name="to" placeholder="Куда">
  <button type="submit">Найти рейс</button>
</form>